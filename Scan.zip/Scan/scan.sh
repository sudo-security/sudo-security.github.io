

#!/bin/bash
#Z3R0FY
#Proğram özetle Sikiş yapıyor 

clear
echo "LS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0K" |base64 -d
echo "CiBfX19fX19fX19fIF9fX18gICBfX18gIF9fX19fX18gICBfXwp8X18gIC9fX18gL3wgIF8gXCAv
IF8gXHwgIF9fX1wgXCAvIC8KICAvIC8gIHxfIFx8IHxfKSB8IHwgfCB8IHxfICAgXCBWIC8gCiAv
IC9fIF9fXykgfCAgXyA8fCB8X3wgfCAgX3wgICB8IHwgIAovX19fX3xfX19fL3xffCBcX1xfX18v
fF98ICAgICB8X3wgIAoK
" |base64 -d
echo "LS0tLS0tLS0tLS0tLS0tLS0tLS0tLUNvZGRlZCBCeSBaM3IwZnktLS0tLS0tLS0tLS0K" |base64 -d
echo "
1)- Multiple Scanner
2)- Site List Maker
3)- Automatic Reverse IP
4)- Link Scanner
5)- About
6)- Clear txt files
"

echo -n "TOOL ==>> " ;read z3

    if (($z3 == 1))
    then
    clear
echo "LS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0K" |base64 -d
echo "CiBfX19fX19fX19fIF9fX18gICBfX18gIF9fX19fX18gICBfXwp8X18gIC9fX18gL3wgIF8gXCAv
IF8gXHwgIF9fX1wgXCAvIC8KICAvIC8gIHxfIFx8IHxfKSB8IHwgfCB8IHxfICAgXCBWIC8gCiAv
IC9fIF9fXykgfCAgXyA8fCB8X3wgfCAgX3wgICB8IHwgIAovX19fX3xfX19fL3xffCBcX1xfX18v
fF98ICAgICB8X3wgIAoK
" |base64 -d
echo "LS0tLS0tLS0tLS0tLS0tLS0tLS0tLUNvZGRlZCBCeSBaM3IwZnktLS0tLS0tLS0tLS0K" |base64 -d

    echo -n "Site List : " ;read siteler
    echo -n "Admin List : " ;read adm
    echo -n "Request Timeout : " ;read time
    python z.py $siteler $adm $time E
    fi
    
        if (($z3 == 2))
        then
        clear
      
        echo "LS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0K" |base64 -d
echo "CiBfX19fX19fX19fIF9fX18gICBfX18gIF9fX19fX18gICBfXwp8X18gIC9fX18gL3wgIF8gXCAv
IF8gXHwgIF9fX1wgXCAvIC8KICAvIC8gIHxfIFx8IHxfKSB8IHwgfCB8IHxfICAgXCBWIC8gCiAv
IC9fIF9fXykgfCAgXyA8fCB8X3wgfCAgX3wgICB8IHwgIAovX19fX3xfX19fL3xffCBcX1xfX18v
fF98ICAgICB8X3wgIAoK
" |base64 -d
echo "LS0tLS0tLS0tLS0tLS0tLS0tLS0tLUNvZGRlZCBCeSBaM3IwZnktLS0tLS0tLS0tLS0K" |base64 -d
echo "Konumunuz : $(tput setaf 2)$(tput bold)$PWD$(tput sgr0)"
echo -n "Site listesi giriniz: ";read liste
if [[ $liste == "" ]]
then
    echo "$(tput setaf 1)$(tput bold)Site listesi girmediniz!$(tput sgr0)"
    exit
fi
echo "$(tput setaf 1)$(tput bold)$liste$(tput sgr0) Seciyorsunuz eminmisiniz Y/n";read karar

if [[ $karar == "y" ]]
then
     awk ' { print"http://"$1"/" } ' $liste >> hacked.txt
     echo "$PWD/hacked.txt dosyasina kaydedildi."
    elif [[ $karar == "Y" ]]
    then
        awk ' { print"http://"$1"/" } ' $liste >> hacked.txt
        echo "$PWD/hacked.txt dosyasina kaydedildi."
        elif [[ $karar == "" ]]
    then
        awk ' { print"http://"$1"/" } ' $liste >> hacked.txt
        echo "$PWD/hacked.txt dosyasina kaydedildi."
else
    exit
fi
fi
            if (($z3 == 3))
            then
            clear
echo "LS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0K" |base64 -d
echo "CiBfX19fX19fX19fIF9fX18gICBfX18gIF9fX19fX18gICBfXwp8X18gIC9fX18gL3wgIF8gXCAv
IF8gXHwgIF9fX1wgXCAvIC8KICAvIC8gIHxfIFx8IHxfKSB8IHwgfCB8IHxfICAgXCBWIC8gCiAv
IC9fIF9fXykgfCAgXyA8fCB8X3wgfCAgX3wgICB8IHwgIAovX19fX3xfX19fL3xffCBcX1xfX18v
fF98ICAgICB8X3wgIAoK
" |base64 -d
echo "LS0tLS0tLS0tLS0tLS0tLS0tLS0tLUNvZGRlZCBCeSBaM3IwZnktLS0tLS0tLS0tLS0K" |base64 -d

                echo -n "Site : " ;read bok                                
                    curl http://api.hackertarget.com/reverseiplookup/?q=$bok                                   
            fi
            
                    
                    if ((z3 == 4))  
                      
                    then
clear
echo "LS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0K" |base64 -d
echo "CiBfX19fX19fX19fIF9fX18gICBfX18gIF9fX19fX18gICBfXwp8X18gIC9fX18gL3wgIF8gXCAv
IF8gXHwgIF9fX1wgXCAvIC8KICAvIC8gIHxfIFx8IHxfKSB8IHwgfCB8IHxfICAgXCBWIC8gCiAv
IC9fIF9fXykgfCAgXyA8fCB8X3wgfCAgX3wgICB8IHwgIAovX19fX3xfX19fL3xffCBcX1xfX18v
fF98ICAgICB8X3wgIAoK
" |base64 -d
echo "LS0tLS0tLS0tLS0tLS0tLS0tLS0tLUNvZGRlZCBCeSBaM3IwZnktLS0tLS0tLS0tLS0K" |base64 -d

                    echo -n "Site : " ;read pipi 
                    curl http://api.hackertarget.com/pagelinks/?q=$pipi
                    fi
                    
                        if ((z3 == 5))
                        then
                        clear
                       
echo "
**********************************
        Codder :z3r0fy
       Priv8 Fucking Tool
          t.me/z3r0fy
**********************************
"
                        fi
                                 if (($z3 == 6))
                                   then
                                     clear
                                     echo "[+] clearing.."
                                          rm wordpress.txt
                                          rm cikanlar.txt
                                          rm joomla.txt
                                          rm opencart.txt
                                          rm hacked.txt
                                          clear
                                          echo "[+] cleared..."
                                          bash scan.sh
                                          fi
